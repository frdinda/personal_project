<?php

namespace App\Controllers\Login;

use App\Controllers\BaseController;
use App\Models\UserModel;

class Login extends BaseController
{
    protected $userModel;
    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function maintenance()
    {
        return view('login/maintenance');
    }

    public function index()
    {
        $data = [
            'nama_page' => 'login'
        ];
        return view('login/login', $data);
    }

    public function ProsLogin()
    {
        $id_user = $this->request->getVar('id_user');
        $password = md5($this->request->getVar('password'));
        $user = $this->userModel->get_detail_user($id_user);
        if (isset($user)) {
            if ($user['password'] == $password) {
                $this->session->set('akses', $user['jenis_akses']);
                $this->session->set('nama_user', $user['nama_user']);
                $this->session->set('id_user', $user['id_user']);
                return redirect()->to('/beranda');
            } else if (empty($user['id_user']) || $user['password'] != $password) {
                echo "<script>
                alert('User ID Atau Password Salah, Silahkan Login Kembali');
                window.location.href='/';
                </script>";
            }
        } else {
            echo "<script>
            alert('Anda Tidak Memiliki Akses');
            window.location.href='/';
            </script>";
        }
    }

    public function logout()
    {
        unset($_SESSION['nama_user']);
        unset($_SESSION['akses']);
        unset($_SESSION['id_user']);
        unset($_SESSION['nama_page']);
        return redirect()->to('/');
    }
}
