<?php

namespace App\Models;

use CodeIgniter\Model;
// use CodeIgniter\Database\ConnectionInterface;

class UserModel extends Model
{
    protected $table      = 'ms_user';
    protected $primaryKey = 'id_user';

    protected $allowedFields = ['id_user', 'nama_user', 'jenis_akses', 'jabatan', 'password'];

    public function get_user()
    {
        return $this->db->table('ms_user')->get()->getResultArray();
    }

    public function get_detail_user($id_user)
    {
        return $this->db->table('ms_user')
            ->where('id_user', $id_user)
            ->get()->getRowArray();
    }
}
