<?php

namespace App\Models;

use CodeIgniter\Model;
// use CodeIgniter\Database\ConnectionInterface;

class PembagianSoalModel extends Model
{
    protected $table      = 'ms_pembagian_soal';
    protected $primaryKey = 'id_pembagian';

    protected $allowedFields = ['id_pembagian', 'id_satker', 'id_soal'];
}
