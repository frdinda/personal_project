<?php

namespace App\Models;

use CodeIgniter\Model;
// use CodeIgniter\Database\ConnectionInterface;

class NilaiModel extends Model
{
    protected $table      = 'tr_penilaian';
    protected $primaryKey = 'id_penilaian';

    protected $allowedFields = ['id_penilaian', 'id_user', 'id_satker', 'id_soal', 'nilai', 'simpulan'];

    public function get_nilai_dashboard()
    {
        return $this->db->table('tr_penilaian')
            ->join('ms_user', 'tr_penilaian.id_user=ms_user.id_user', 'LEFT')
            ->join('ms_satker', 'tr_penilaian.id_satker=ms_satker.id_satker', 'LEFT')
            ->join('ms_soal', 'tr_penilaian.id_soal=ms_soal.id_soal', 'LEFT')
            ->groupBy('tr_penilaian.id_penilaian')
            ->orderBy('tr_penilaian.id_satker', 'ASC')
            ->get()->getResultArray();
    }

    public function get_nilai_satker($id_satker)
    {
        return $this->db->table('tr_penilaian')
            ->where('tr_penilaian.id_satker', $id_satker)
            ->join('ms_user', 'tr_penilaian.id_user=ms_user.id_user', 'LEFT')
            ->join('ms_satker', 'tr_penilaian.id_satker=ms_satker.id_satker', 'LEFT')
            ->join('ms_soal', 'tr_penilaian.id_soal=ms_soal.id_soal', 'LEFT')
            ->groupBy('tr_penilaian.id_penilaian')
            ->orderBy('tr_penilaian.id_satker', 'ASC')
            ->get()->getResultArray();
    }

    public function get_pembagian_soal()
    {
        return $this->db->table('ms_pembagian_soal')
            ->groupBy('ms_pembagian_soal.id_pembagian')
            ->get()->getResultArray();
    }

    public function get_pembagian_soal_satker($id_satker)
    {
        return $this->db->table('ms_pembagian_soal')
            ->where('ms_pembagian_soal.id_satker', $id_satker)
            ->join('ms_soal', 'ms_pembagian_soal.id_soal=ms_soal.id_soal', 'LEFT')
            ->groupBy('ms_pembagian_soal.id_pembagian')
            ->get()->getResultArray();
    }

    public function get_soal_pertama($id_satker)
    {
        return $this->db->table('ms_pembagian_soal')
            ->where('ms_pembagian_soal.id_satker', $id_satker)
            ->limit(1)
            ->get()->getRowArray();
    }

    public function get_nilai_satker_persoal($id_soal, $id_satker, $id_user)
    {
        return $this->db->table('tr_penilaian')
            ->where('tr_penilaian.id_soal', $id_soal)
            ->where('tr_penilaian.id_satker', $id_satker)
            ->where('tr_penilaian.id_user', $id_user)
            ->get()->getRowArray();
    }
}
